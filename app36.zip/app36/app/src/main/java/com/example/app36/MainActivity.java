//Notification creation
package com.example.app36;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button b;
    TextView t;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b=findViewById(R.id.button);
        t=findViewById(R.id.text);
        // we do this at last
        Intent i1= getIntent();
        t.setText(i1.getStringExtra("message"));


        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NotificationManager m= (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                // we've to explicitly set to (NotificationManager)
                //we can associate notification with pending intent i.e waiting for some acton to happen
                Intent i= new Intent(MainActivity.this, MainActivity.class);
                i.putExtra("message","Task completed");
                // here we're opening the same main page on click of button hence second parameter is Mainactivity.class
                PendingIntent pi= PendingIntent.getActivity(MainActivity.this,1,i,PendingIntent.FLAG_UPDATE_CURRENT);
                // here i because this pending intent is waiting for i to happen


                // we've to check for build version for notification android if >= 26 bc there's a notification channel associated with it
                if(Build.VERSION.SDK_INT>=26)
                {
                    NotificationChannel nc= new NotificationChannel("ch1","channel1",NotificationManager.IMPORTANCE_HIGH);
                    m.createNotificationChannel(nc);
                    Notification.Builder nb= new Notification.Builder(MainActivity.this,"ch1");
                    nb.setContentIntent(pi);
                    nb.setContentTitle("Notification");
                    //nb.setContentText("Task completed"); Instead of this we're creating i1
                    nb.setAutoCancel(true);
                    // false will keep the notification in the panel even after clicking it and to remove it we've to push it
                    // true will remove the notification on clicking it
                    nb.setSmallIcon(R.drawable.imag1);
                    Notification not= nb.build();
                    m.notify(2,not);
                }
                else
                {
                    Notification.Builder nb= new Notification.Builder(MainActivity.this);
                    nb.setContentIntent(pi);
                    nb.setContentTitle("Notification");
                    nb.setContentText("Task completed");
                    nb.setAutoCancel(true);
                    nb.setSmallIcon(R.drawable.imag1);
                    Notification not= nb.build();
                    m.notify(2,not);
                }
            }
        });
    }
}