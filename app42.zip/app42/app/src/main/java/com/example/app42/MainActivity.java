//ContentProviders

package com.example.app42;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.pm.ActivityInfoCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Button b;
    ListView lv;
    ArrayAdapter<String> adp;
    ArrayList<String> arr= new ArrayList<String>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b=findViewById(R.id.button);
        lv=findViewById(R.id.listview);
        adp=new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1,arr);
        lv.setAdapter(adp);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_CONTACTS)!= PackageManager.PERMISSION_GRANTED)
                    ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.READ_CONTACTS},1);
                else
                {
                    Cursor c= getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER},null,null,null);
                    if(c.getCount()>0)
                    {
                        if(c.moveToFirst())
                        {
                            do{
                                String name=c.getString(0);
                                String num=c.getString(1);
                                arr.add("Name: "+name+"\nNumber: "+num);

                            }while(c.moveToNext());
                            adp.notifyDataSetChanged();
                        }
                    }
                }
            }
        });
    }
}