package com.example.app7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    Button b;
    ImageView i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b=findViewById(R.id.button);
        i=findViewById(R.id.image);
        b.setOnClickListener(new View.OnClickListener() {
            int c=0;
            @Override
            public void onClick(View view) {
                if(c==0)
                {
                    i.setImageResource(R.drawable.catto1);
                    c=1;
                }
                else
                {
                    i.setImageResource(R.drawable.doge2);
                    c=0;
                }

            }
        });
    }
}