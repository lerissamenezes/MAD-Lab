// call broadcast receiver using CALL_STATE
package com.example.app29;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TelephonyManager tm;
    PhoneStateListener ph;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tm=(TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        ph =new PhoneStateListener(){
            @Override
            public void onCallStateChanged(int state, String phoneNumber) {
                super.onCallStateChanged(state, phoneNumber);
                if(state== TelephonyManager.CALL_STATE_RINGING)
                {
                    Toast.makeText(MainActivity.this, "RINGING", Toast.LENGTH_SHORT).show();
                }
                if(state==TelephonyManager.CALL_STATE_OFFHOOK)
                {
                    Toast.makeText(MainActivity.this, "OFF HOOK", Toast.LENGTH_SHORT).show();
                }
                if(state==TelephonyManager.CALL_STATE_IDLE)
                {
                    Toast.makeText(MainActivity.this, "IDLE", Toast.LENGTH_SHORT).show();
                }
                // This much is nit sufficient to execute. We've to link them
            }
        };
        tm.listen(ph,PhoneStateListener.LISTEN_CALL_STATE);
    }
}