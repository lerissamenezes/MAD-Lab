//Async Task
package com.example.app25;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/*
         Async Task has three parameters
         AsyncTsk<P1,P2,P3>
         {

            Input parameter P1 is from external environment to the method i.e incoming. Integer wrt counter example
            Progress parameter P2 is from start to completion of intermediate task. Datatype of value to be displayed ont he textview. Integer
            Output parameter P3 represents the value to be returned after the completion of background task. can be void if not returning anything

            doInBackground()
            {
                // tasks needed to be performed in the background
            }
            onPreExecute()
            {
             // called before background task is started
            }
            onProgressUpdate
            {
                // called only if need to see what happens in the background
            }
            onPreExecute()
            {
              // called after background task is completed
            }
         }



         */

public class MainActivity extends AppCompatActivity {

    Button b1, b2, b3;
    TextView tv;

    int count = 0;
    boolean counting = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = findViewById(R.id.start);
        b2 = findViewById(R.id.stop);
        b3 = findViewById(R.id.reset);
        tv = findViewById(R.id.text);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                counting = true;
                CounterTask ct = new CounterTask(); //object of asynctask
                ct.execute(count) ; // passing parameter because it de
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                counting=false;
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                counting=false;
                count=0;
                tv.setText(0+"");
            }
        });
    }

    class CounterTask extends AsyncTask<Integer, Integer, Void> {

    protected Void doInBackground(Integer... integers) {
            //We've to write in terms of class datatype
            // doInBackground parameters are the ones received from ct.execute() from Mainactivity
            // ... integers. here integers is an array that takes variable arguments passed in execute
            // int val = integers[0]; this statement results in error in reset as it dangles between 0 and 1
            while (counting) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                // val++; updation is in foreground
                //publishProgress(val);

                count++; // updation is in foreground
                //tv.setText(count+""); wont work
                publishProgress(count);
            }
            return null;
        }


        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // executed first
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            // val from return val is given to values of this method
            // this will display
            tv.setText(values[0] + "");
        }

        /*
        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);
            // used to update the foreground elements i.e the UI elements
            counting=false;
            count = integer;
        }
        */


    }
}