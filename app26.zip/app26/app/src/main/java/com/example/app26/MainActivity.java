// AsyncTask: Program has to sleep for particular duration and display a toast. While the background tasks is
//	sleeping, we should still be able to use foreground elements like in downloading.
//	Also uses progress dialog as a spinner
package com.example.app26;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button b;
    EditText e;
    ProgressDialog pd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b=findViewById(R.id.button);
        e=findViewById(R.id.text);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int time = Integer.parseInt(e.getText().toString());
                TimeAsyncTask t= new TimeAsyncTask();
                t.execute(time);
            }
        });
    }
    class TimeAsyncTask extends AsyncTask<Integer,Integer,String>{

       /* @Override
        protected void onPreExecute() {
        // gives only spinner
            super.onPreExecute();
            pd= new ProgressDialog(MainActivity.this);
            pd.setMessage("Wait...");
            pd.show();
        }*/
        // for Spinner. the three parameters for AsyncTask are Integer, Void and String
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd= new ProgressDialog(MainActivity.this);
            pd.setMessage("Wait...");
            pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            pd.show();
        }

        @Override
        protected String doInBackground(Integer... integers) {
            //time is received in integers
            int count =0;
            int target=integers[0]; // extracting maximum value for pausing
            // from here, for Horizontal progress bar
            pd.setMax(target);
            while(count<target){
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException interruptedException) {
                    interruptedException.printStackTrace();
                }
                count++;
                publishProgress(count);
            }
            // till here, for Horizontal progress bar
            try {
                Thread.sleep(integers[0]*1000);
            } catch (InterruptedException interruptedException) {
                interruptedException.printStackTrace();
            }

            String res= "Sleep completed for "+integers[0]+" seconds";
            return res;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            pd.setProgress(values[0]);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.cancel();
            Toast.makeText(MainActivity.this, s, Toast.LENGTH_SHORT).show();
        }
    }
}