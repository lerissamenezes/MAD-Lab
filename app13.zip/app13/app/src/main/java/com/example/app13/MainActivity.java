package com.example.app13;
/* right click on res and new-> Directory then on menu right click and new-> resource file
*
* there is no field text in menu item it is of the type attribute title*/
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText n1, n2;
    TextView t;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        n1 = findViewById(R.id.text1);
        n2 = findViewById(R.id.text_2);
        t = findViewById(R.id.display);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.optionmenu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(n1.getText().toString().equals("") || n2.getText().toString().equals(""))
            Toast.makeText(MainActivity.this,"Enter both the numbers",Toast.LENGTH_SHORT).show();
        else {
            int num1 = Integer.parseInt(n1.getText().toString());
            int num2 = Integer.parseInt(n2.getText().toString());
            int id = item.getItemId();
            switch (id) {
                case R.id.add:
                    float sum = num1 + num2;
                    t.setText(sum + ""); // append null string to convert int to string
                    break;
                case R.id.sub:
                    float diff = num1 - num2;
                    t.setText(diff + "");
                    break;
                case R.id.mul:
                    float pro = num1 * num2;
                    t.setText(pro + "");
                case R.id.div:
                    if (num2 != 0) {
                        float quo = num1 / num2;
                        t.setText(quo + "");
                    } else {
                        Toast.makeText(MainActivity.this, "Division by 0", Toast.LENGTH_SHORT).show();
                    }
            }
        }
        return super.onOptionsItemSelected(item);
    }
    /*
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.optionmenu,menu);  // inflation process is attaching xml file to main activity
        return super.onCreateOptionsMenu(menu);
    }

    // to associate action with the option menu we need a new method

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {  // parameter is the selected item on the option menu.
        Toast.makeText(MainActivity.this,item.getTitle().toString(),Toast.LENGTH_SHORT).show();
        return super.onOptionsItemSelected(item);

     */
}