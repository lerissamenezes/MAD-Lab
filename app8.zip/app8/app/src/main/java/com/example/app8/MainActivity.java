package com.example.app8;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    RadioGroup rg;
    ConstraintLayout cl;
    Button b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rg=findViewById(R.id.radio);
        cl=findViewById(R.id.layout);
        b=findViewById(R.id.button);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id=rg.getCheckedRadioButtonId();
                if(id==-1)
                    Toast.makeText(MainActivity.this,"None selected",Toast.LENGTH_SHORT).show();
                else
                {
                    RadioButton r1=findViewById(id);
                    if(r1.getText().toString().equals("Red"))
                        cl.setBackgroundColor(Color.RED);
                    else if(r1.getText().toString().equals("Blue"))
                        cl.setBackgroundColor(Color.BLUE);
                    else 
                        cl.setBackgroundColor(Color.GREEN);
                }



            }
        });
    }
}