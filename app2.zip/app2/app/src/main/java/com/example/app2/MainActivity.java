package com.example.app2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button a;
    EditText n1,n2;
    TextView t;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        a=findViewById(R.id.add);
        n1=findViewById(R.id.num1);
        n2=findViewById(R.id.num2);
        t=findViewById(R.id.res);
        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int num1=0,num2=0;
                if(n1.getText().toString().isEmpty() || n2.getText().toString().isEmpty())
                    Toast.makeText(MainActivity.this,"Enter both the numbers!!",Toast.LENGTH_SHORT).show();
                else {
                    num1 = Integer.parseInt(n1.getText().toString());
                    num2 = Integer.parseInt(n2.getText().toString());
                    int sum = num1 + num2;
                    Toast.makeText(MainActivity.this, "Sum = " + sum, Toast.LENGTH_SHORT).show();
                    t.setText(sum + "");
                }
            }
        });
    }
}