//Call Broadcast Receiver
package com.example.app28;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

/* there are 3 states
    ringing
    off hook
    idle

 here we do the registration for intent in the manifest file
*/

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // we've to check if permissions is given to package manager or not
         // this we've done in phone settings in app  management

    }
}