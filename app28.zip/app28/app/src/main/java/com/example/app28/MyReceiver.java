package com.example.app28;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import android.widget.Toast;

public class MyReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving
        // an Intent broadcast.
        //throw new UnsupportedOperationException("Not yet implemented");
        // State info here is given in the form of a string
        String state= intent.getStringExtra(TelephonyManager.EXTRA_STATE);
        Toast.makeText(context, state, Toast.LENGTH_SHORT).show();
        // extracting phone number from intent
        String ph= intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);
        if(ph!=null)
            Toast.makeText(context,"Phone number is "+ph, Toast.LENGTH_SHORT).show();

    }
}