//Broadcast Receiver for battery level
package com.example.app27;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView t;
    ConstraintLayout l;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        l=findViewById(R.id.l);
        t=findViewById(R.id.tv);
        BatteryBroadcastReceiver b = new BatteryBroadcastReceiver();
        registerReceiver(b,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
    //
    }
    // Two ways: same file and a new java file

    class BatteryBroadcastReceiver extends BroadcastReceiver{
        @Override
        public void onReceive(Context context, Intent intent) {
            int status= intent.getIntExtra("level",0);
            if(status>=60)
                l.setBackgroundColor(Color.GREEN);
            else if(status>=30)
                l.setBackgroundColor(Color.BLUE);
            else
                l.setBackgroundColor(Color.RED);
            t.setText("Status: "+status+"%");

        }
    }

}