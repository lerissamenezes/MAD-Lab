package com.example.app12;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    RadioGroup rg;
    ConstraintLayout cl; // creation of objects

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rg = findViewById(R.id.radio); // initialization of object
        cl = findViewById(R.id.layout);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) { // within the radiogroup, the colour changed radiobutton is indicated by i
                if(i==R.id.button1)
                    cl.setBackgroundColor(Color.RED);
                else if(i==R.id.button2)
                    cl.setBackgroundColor(Color.BLUE);
                else
                    cl.setBackgroundColor(Color.GREEN);


                /*
                RadioButton ri=findViewById(i);
                if(ri.getText().toString().equals("Red"))
                    cl.setBackgroundColor(Color.RED);
                else if(ri.getText().toString().equals("Blue"))
                    cl.setBackgroundColor(Color.BLUE);
                else
                    cl.setBackgroundColor(Color.GREEN);

                    both codes are correct

                    OR

                    switch(i)
                    {
                        case R.id.red: cl.setBackgroundColor(Color.RED);
                                        break;
                        case R.id.blue: cl.setBackgroundColor(Color.BLUE);
                                        break;
                        case R.id.green: cl.setBackgroundColor(Color.GREEN);
                                        break;
                    }*/



            }
        });
        }

}
