package com.example.app17;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

// intent is used to communicate between applications
//EXPLICIT INTENT
public class MainActivity extends AppCompatActivity {

    Button b;
    EditText t;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b=findViewById(R.id.sent);
        t=findViewById(R.id.msg);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // we've to transfer the control to different activity i.e go to different page or application
                // for that we need a new XML file and new activity
                // go to java right click, new and empty activity
                Intent i= new Intent(MainActivity.this,SecondActivity.class);
                String s= t.getText().toString();
                i.putExtra("Message",s);  // sending data in terms of key-value pairs
                startActivity(i); // only when we're only sending data but not receiving

                // We've two parameters in putextra. Here Message is the tag to identify the actual message which is the second parameter
                i.putExtra("msg",20);

                // while sending integer value, on receiving end there should be a default value associated with it, i.getIntExtra("msg",0);





            }
        });
    }
}