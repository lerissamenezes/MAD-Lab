package com.example.app17;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    TextView tt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        tt=findViewById(R.id.tv);
        Intent a= getIntent();
        String s1= a.getStringExtra("Message");
        Integer n = a.getIntExtra("msg",0);
        tt.setText(s1+n);


    }
}