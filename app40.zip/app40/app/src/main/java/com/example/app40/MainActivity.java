// Accelerometer
package com.example.app40;


import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements SensorEventListener{

    TextView x,y,z;
    SensorManager sm;
    AudioManager am;
    Sensor scc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        x=findViewById(R.id.textView1);
        y=findViewById(R.id.textView2);
        z=findViewById(R.id.textView3);
        sm= (SensorManager) getSystemService(SENSOR_SERVICE);
        am= (AudioManager) getSystemService(AUDIO_SERVICE);
        scc=sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        if(scc==null)
        {
            Toast.makeText(MainActivity.this, "Accelerometer is not supported", Toast.LENGTH_SHORT).show();
            finish();
        }
        sm.registerListener(this,scc,SensorManager.SENSOR_DELAY_NORMAL);
    }


  public void onSensorChanged(SensorEvent event)
   {
       float xval= event.values[0];
       float yval= event.values[1];
       float zval= event.values[2];

       x.setText("X : "+xval);
       y.setText("Y : "+yval);
       z.setText("Z : "+zval);

       if(zval>=0 && yval>=0)
       {
           if(am.getRingerMode()!=AudioManager.RINGER_MODE_VIBRATE)
           {
               am.setRingerMode(AudioManager.RINGER_MODE_VIBRATE);
               Toast.makeText(MainActivity.this, "Set on vibrate", Toast.LENGTH_SHORT).show();
           }
       }
       if(xval>=0 && yval>=0)
       {
           if(am.getRingerMode()!=AudioManager.RINGER_MODE_NORMAL)
           {
               am.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
               Toast.makeText(MainActivity.this, "Set on normal", Toast.LENGTH_SHORT).show();
           }
       }
   }


   public void onAccuracyChanged(Sensor sensor, int accuracy)
   {

   }
    @Override
    protected void onPause() {
        super.onPause();
        sm.unregisterListener((SensorEventListener) MainActivity.this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        sm.registerListener((SensorEventListener) MainActivity.this,scc,SensorManager.SENSOR_DELAY_NORMAL);
    }
}