package com.example.app23;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText m,p;
    Button b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        m=findViewById(R.id.msg);
        p=findViewById(R.id.phone);
        b=findViewById(R.id.button);
        b.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
                // To send a SMS, we need to create an object of type SmsManager
                SmsManager sms=SmsManager.getDefault();
                // to check if permission is granted or not
                if(checkSelfPermission(Manifest.permission.SEND_SMS)!= PackageManager.PERMISSION_GRANTED)
                {
                    requestPermissions(new String[]{Manifest.permission.SEND_SMS},1);

                }
                else
                {
                    sms.sendTextMessage(p.getText().toString(),null,m.getText().toString(),null,null);
                    Toast.makeText(MainActivity.this,"Message sent",Toast.LENGTH_SHORT).show();
                }

                // sms.sendTextMessage(p.getText().toString(),null, m.getText().toString(),null,null);

                // null means source device
                // sentIntent indicates if any action has to be taken after sending the message
                // deliveryIntent indicates if any action has to be taken after delivering the message

                //till her eif you give run, the app won't run bc permissions are not set bc we're not creating an interface between
                // a calling app and this app rather we're directly placing a call with permissions.
                // therefore set uses-permissions in Manifest file


            }


        });

    }
}