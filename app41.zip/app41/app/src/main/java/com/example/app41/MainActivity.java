// Gyroscope
package com.example.app41;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements SensorEventListener{

    TextView x,y,z;
    SensorManager sm;
    Sensor gyroscope;
    ConstraintLayout l;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        l=findViewById(R.id.layout);
        x=findViewById(R.id.textView1);
        y=findViewById(R.id.textView2);
        z=findViewById(R.id.textView3);
        sm= (SensorManager) getSystemService(SENSOR_SERVICE);
        gyroscope=sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);

        if(gyroscope==null)
        {
            Toast.makeText(MainActivity.this, "Gyroscope not supported", Toast.LENGTH_SHORT).show();
            finish();
        }
        sm.registerListener(this,gyroscope,SensorManager.SENSOR_DELAY_NORMAL);
    }

    public void onSensorChanged(SensorEvent event)
    {
        float xval=event.values[0];
        float yval=event.values[1];
        float zval=event.values[2];

        x.setText("X : "+xval);
        y.setText("Y : "+yval);
        z.setText("Z : "+zval);

        if(zval>0.5)
            l.setBackgroundColor(Color.RED);
        else
            l.setBackgroundColor(Color.GREEN);
    }

    public void onAccuracyChanged(Sensor sensor,int accuracy)
    {

    }

    @Override
    protected void onPause() {
        super.onPause();
        sm.unregisterListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        sm.registerListener(this,gyroscope,SensorManager.SENSOR_DELAY_NORMAL);
    }
}