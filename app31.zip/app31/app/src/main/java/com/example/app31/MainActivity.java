//SQLite database - employee
package com.example.app31;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button b1,b2,b3,b4;
    EditText e1,e2,e3,e4;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = findViewById(R.id.button1);
        b2 = findViewById(R.id.button2);
        b3 = findViewById(R.id.button3);
        b4 = findViewById(R.id.button4);
        e1 = findViewById(R.id.text1);
        e2 = findViewById(R.id.text2);
        e3 = findViewById(R.id.text3);
        e4 = findViewById(R.id.text4);

        db=openOrCreateDatabase("EmployeeDB",MODE_PRIVATE,null);
        //MODE_PRIVATE ensures that db is not accessible to any other application
        db.execSQL("CREATE TABLE IF NOT EXISTS Employee(ID varchar(10) primary key, Name varchar(20), Department varchar(20),Salary int)");
        // helps to execute SQL commands
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String i=e1.getText().toString();
                String n=e2.getText().toString();
                String d=e3.getText().toString();
                int s;
                if(e4.getText().toString().equals(""))
                    s=0;
                else
                    s=Integer.parseInt(e4.getText().toString());

                Cursor c=db.rawQuery("SELECT * FROM Employee WHERE ID=?",new String[]{i});
                if(c.getCount()==0) {
                    db.execSQL("INSERT INTO Employee Values('" + i + "','" + n + "','" + d + "',"+s+")");
                    // before insertion we've to check for primary key overlap
                    Toast.makeText(MainActivity.this, "Data inserted successfully", Toast.LENGTH_SHORT).show();
                }
                else
                    Toast.makeText(MainActivity.this, "ID already exists", Toast.LENGTH_SHORT).show();
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String i=e1.getText().toString();
                if(i.equals(""))
                    Toast.makeText(MainActivity.this, "Enter the employee ID to be deleted", Toast.LENGTH_SHORT).show();
                else
                {
                    db.execSQL("DELETE FROM Employee WHERE ID=?",new Object[]{i});
                    Toast.makeText(MainActivity.this, "Data is deleted successfully", Toast.LENGTH_SHORT).show();
                }
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String i=e1.getText().toString();
                String n=e2.getText().toString();
                String d=e3.getText().toString();
                int s;
                if(e4.getText().toString().equals(""))
                    s=0;
                else
                    s=Integer.parseInt(e4.getText().toString());
                if(!i.equals(""))
                {
                    db.execSQL("UPDATE Employee SET ID='"+i+"',Name='"+n+"',Department='"+d+"',Salary='"+s+"' WHERE ID =?",new Object[]{i});
                    Toast.makeText(MainActivity.this, "Data is updated successfully", Toast.LENGTH_SHORT).show();
                }

            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor c= db.rawQuery("SELECT * FROM Employee",null);
                //rawQuery has atleast 2 parameter
                if(c.getCount()==0)
                {
                    Toast.makeText(MainActivity.this, "No data", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    String all=""; // to store all the rows
                    while(c.moveToNext()) // this function moves to consecutive rows on every iteration
                    {
                        String i=c.getString(0); // 0 is the index at which ID is present in the table
                        String n= c.getString(1);
                        String d=c.getString(2);
                        int s= c.getInt(3);
                        all+="ID: "+i+"\nName: "+n+"\nDepartment: "+d+"\nSalary: Rs."+s+"\n\n";
                    }
                    AlertDialog.Builder alert=new AlertDialog.Builder(MainActivity.this);
                    alert.setTitle("Details");
                    alert.setMessage(all);
                    AlertDialog a= alert.create();
                    a.show();
                }
            }
        });

    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        db.close();
    }
}