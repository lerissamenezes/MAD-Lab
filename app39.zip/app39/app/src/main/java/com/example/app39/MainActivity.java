//Animations
package com.example.app39;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.animation.ObjectAnimator;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    ImageView iv;
    Button rotate, scale,translate,transparent,background,image;
    ConstraintLayout l;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        iv=findViewById(R.id.imageView);
        l=findViewById(R.id.layout);
        rotate=findViewById(R.id.button1);
        image=findViewById(R.id.button2);
        scale=findViewById(R.id.button3);
        translate=findViewById(R.id.button4);
        transparent=findViewById(R.id.button5);
        background=findViewById(R.id.button6);

        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                iv.setImageResource(0);
                iv.setBackgroundResource(R.drawable.image_anim);
                AnimationDrawable an=(AnimationDrawable) iv.getBackground();
                an.start();
            }
        });

        rotate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                iv.setImageResource(0);
                iv.setBackgroundResource(R.drawable.img1);
                Animation rot = AnimationUtils.loadAnimation(MainActivity.this,R.anim.rotate);
                iv.startAnimation(rot);

            }
        });

        scale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                iv.setImageResource(0);
                iv.setBackgroundResource(R.drawable.img1);
                Animation sc= AnimationUtils.loadAnimation(MainActivity.this,R.anim.scale);
                iv.startAnimation(sc);
            }
        });

        translate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                iv.setImageResource(0);
                iv.setBackgroundResource(R.drawable.img1);
                Animation tsl=AnimationUtils.loadAnimation(MainActivity.this,R.anim.translate);
                iv.startAnimation(tsl);

            }
        });

        transparent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                iv.setImageResource(0);
                iv.setBackgroundResource(R.drawable.img1);
                Animation tsp=AnimationUtils.loadAnimation(MainActivity.this,R.anim.transparent);
                iv.startAnimation(tsp);

            }
        });

        background.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                iv.setImageResource(0);
                ObjectAnimator ob= ObjectAnimator.ofInt(l,"backgroundColor", Color.RED,Color.YELLOW);
                ob.setDuration(2000);
                ob.start();

            }
        });
    }
}