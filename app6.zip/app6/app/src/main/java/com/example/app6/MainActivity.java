package com.example.app6;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button b;
    ImageView i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b=findViewById(R.id.button);
        i=findViewById(R.id.image);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                i.setImageResource(R.drawable.doge);
                Toast.makeText(MainActivity.this,"feed me hooman",Toast.LENGTH_SHORT).show();
            }
        });
    }
}