//System camera for videos
package com.example.app34;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {

    Button c,p;
    VideoView vv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        c = findViewById(R.id.button1);
        p = findViewById(R.id.button2);
        vv = findViewById(R.id.videoView);

        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
                startActivityForResult(i, 1);

            }
        });

        p.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                //MediaStore.Images.Media.EXTERNAL_CONTENT_URI) this can be internal
                // //ie. images specific to the application or the external i.e global images
                startActivityForResult(i, 2);
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // result of intent will be here in third parameter of this method ie. data
        if (requestCode == 1 && resultCode == RESULT_OK) {
            Uri u = data.getData();
            vv.setVideoURI(u);
            vv.start();
        }

        if (requestCode == 2 && resultCode == RESULT_OK) {
            Uri u = data.getData();
            vv.setVideoURI(u);
            vv.start();
        }
    }
}