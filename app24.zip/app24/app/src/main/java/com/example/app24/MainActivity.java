//Thread counter
package com.example.app24;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.awt.font.TextAttribute;

public class MainActivity extends AppCompatActivity {

    Button b1,b2,b3;
    TextView t;
    int count=0;
    boolean counting=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.start);
        b2=findViewById(R.id.stop);
        b3=findViewById(R.id.reset);
        t=findViewById(R.id.text);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                counting = true;
                Thread th = new Thread(new Runnable() {
                    @Override
                    public void run() {

                        while (counting) {
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            count++;

                            t.post(new Runnable() {
                                @Override
                                public void run() {
                                    t.setText(count + "");
                                }
                            });
                        }
                    }
                });
                //t.setText(count+"");
                // this is crashing because thread.sleep is blocking foreground element
                // we're supposed to put a background thread to sleep
                th.start();
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                counting=false;
            }
        });


        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                count=0;
                t.setText(count+"");
            }
        });
    };
}