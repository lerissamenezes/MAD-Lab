package com.example.app32;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBStudent extends SQLiteOpenHelper {
    public DBStudent(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
        //CursorFactory is a collection of objects using which we can get the results from the database
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        // sqLiteDatabase is a object of SQLiteDatabase
        sqLiteDatabase.execSQL("Create table if not exists Student (ID int primary key,Name varchar(20),Marks int)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public long insertData(int id,String name,int marks)
    {
        // we're inserting the values into the table on the database
        SQLiteDatabase db= getWritableDatabase();
        // here we;re not creating the database again whereas only updating the database created in onCreate
        ContentValues c=new ContentValues();
        c.put("ID",id);
        c.put("Name",name);
        c.put("Marks",marks);

        return db.insert("STUDENT",null,c);

    }

    public Cursor getData()
    {
        SQLiteDatabase db=getWritableDatabase();
        return db.rawQuery("SELECT * FROM STUDENT",null);
    }

    public int deleteData(int id)
    {
        SQLiteDatabase db=getWritableDatabase();

        return db.delete("STUDENT","ID=?",new String[]{String.valueOf(id)});
    }

    public int updateData(int id,String name,int marks)
    {
        SQLiteDatabase db= getWritableDatabase();
        ContentValues c=new ContentValues();
        c.put("Name",name);
        c.put("Marks",marks);
       return  db.update("STUDENT",c,"ID=?",new String[]{String.valueOf(id)});
    }
}
