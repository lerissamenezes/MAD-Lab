//SQLite database -  student using Sqlite OpenHelper class
package com.example.app32;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText i, n, m;
    Button b1, b2, b3, b4;
    DBStudent db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        i = findViewById(R.id.id);
        n = findViewById(R.id.name);
        m = findViewById(R.id.marks);
        b1 = findViewById(R.id.button1);
        b2 = findViewById(R.id.button2);
        b3 = findViewById(R.id.button3);
        b4 = findViewById(R.id.button4);

        db = new DBStudent(MainActivity.this, "StudentDB", null, 1);
        // Create a new java file
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long res = db.insertData(Integer.parseInt(i.getText().toString()), n.getText().toString(), Integer.parseInt(m.getText().toString()));
                if (res == -1)
                    Toast.makeText(MainActivity.this, "No data inserted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(MainActivity.this, "Data inserted successfully", Toast.LENGTH_SHORT).show();
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int res = db.updateData(Integer.parseInt(i.getText().toString()), n.getText().toString(), Integer.parseInt(m.getText().toString()));
                if (res  == 0)
                    Toast.makeText(MainActivity.this, "Updation failed", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(MainActivity.this, "Updated successfully", Toast.LENGTH_SHORT).show();
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int res = db.deleteData(Integer.parseInt(i.getText().toString()));
                if (res == 0)
                    Toast.makeText(MainActivity.this, "No rows deleted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(MainActivity.this, "Deletion succesful", Toast.LENGTH_SHORT).show();

            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor c = db.getData();
                String all = "";
                while (c.moveToNext()) {
                    int i = c.getInt(0);
                    String n = c.getString(1);
                    int m = c.getInt(2);
                    all += "ID: " + i + "\nName: " + n + "\nMarks: " + m + "\n\n";
                }
                AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
                alert.setTitle("Details");
                alert.setMessage(all);
                AlertDialog a = alert.create();
                a.show();
            }

        }

    );

}
}