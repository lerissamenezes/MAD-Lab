//Music Service
package com.example.app43;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.widget.Toast;

public class Music extends Service {

    MediaPlayer mp;
    public void MusicService()
    {

    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mp=MediaPlayer.create(this,R.raw.office_theme);
        mp.setLooping(true);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        mp.start();
        Toast.makeText(this, "Service started", Toast.LENGTH_SHORT).show();
        Notification not;
        if(Build.VERSION.SDK_INT>=26)
        {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            NotificationChannel nc = new NotificationChannel("1", "channel1", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(nc);
            Notification.Builder n= new Notification.Builder(this,"1");
            not=n.build();
        }
        else
        {
            Notification.Builder n= new Notification.Builder(this);
            not=n.build();
        }
        startForeground(123,not);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mp.stop();
        Toast.makeText(this, "Service stopped", Toast.LENGTH_SHORT).show();
    }
}