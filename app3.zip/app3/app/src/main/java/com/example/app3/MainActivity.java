package com.example.app3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Button a;
    ConstraintLayout l;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        a = findViewById(R.id.change);
        l = findViewById(R.id.layout);
        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random rn = new Random();
                int r,g,b;
                r= rn.nextInt(255);
                g= rn.nextInt(255);
                b= rn.nextInt(255);
                l.setBackgroundColor(Color.rgb(r,g,b));
            }
        });
    }
}