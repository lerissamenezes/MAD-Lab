package com.example.app21;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

public class SecondActivity extends AppCompatActivity {

    ConstraintLayout l;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        l=findViewById(R.id.layout);
        Intent a=getIntent();
        int r1=a.getIntExtra("Red",0);
        int g1=a.getIntExtra("Green",0);
        int b1=a.getIntExtra("Blue",0);
        l.setBackgroundColor(Color.rgb(r1,g1,b1));
    }
}