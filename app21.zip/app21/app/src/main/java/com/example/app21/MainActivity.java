// passing of color coordinates from one activity to another and change background color of second activity
package com.example.app21;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button b;
    EditText t1,t2,t3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b=findViewById(R.id.button);
        t1=findViewById(R.id.text1);
        t2=findViewById(R.id.text2);
        t3=findViewById(R.id.text3);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(MainActivity.this,SecondActivity.class);
                int r= Integer.parseInt(t1.getText().toString());
                int g= Integer.parseInt(t2.getText().toString());
                int b= Integer.parseInt(t3.getText().toString());
                i.putExtra("Red",r);
                i.putExtra("Green",g);
                i.putExtra("Blue",b);
                startActivity(i);

            }
        });
    }
}