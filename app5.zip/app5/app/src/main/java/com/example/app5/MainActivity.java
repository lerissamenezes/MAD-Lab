package com.example.app5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    CheckBox c1,c2,c3,c4;
    Button b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        c1=findViewById(R.id.item1);
        c2=findViewById(R.id.item2);
        c3=findViewById(R.id.item3);
        c4=findViewById(R.id.item4);
        b=findViewById(R.id.button);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s="";
                if(c1.isChecked())
                    s=s+c1.getText().toString()+" ";
                if(c2.isChecked())
                    s=s+c2.getText().toString()+" ";
                if(c3.isChecked())
                    s=s+c3.getText().toString()+" ";
                if(c4.isChecked())
                    s=s+c4.getText().toString()+" ";
                if(s.isEmpty())
                    Toast.makeText(MainActivity.this,"No item is selected",Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(MainActivity.this,s+"Selected",Toast.LENGTH_SHORT).show();
            }
        });
    }
}