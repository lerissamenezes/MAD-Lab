package com.example.app18;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    Button b2;
    TextView t2;
    EditText e2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        b2=findViewById(R.id.button2);
        t2=findViewById(R.id.display2);
        e2=findViewById(R.id.send2);
        Intent a=getIntent();
        String s = a.getStringExtra("Message");
        int i= a.getIntExtra("Msg",0);
        t2.setText(s+i);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i2= new Intent();
                String s2= e2.getText().toString();
                i2.putExtra("Message1",s2);
                setResult(2,i2);
                finish();
            }
        });
    }


}