//Shared preferences i.e saves the app's data locally by creating a file
package com.example.app35;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText n,p;
    SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        n=findViewById(R.id.name);
        p=findViewById(R.id.phone);
        sp=getSharedPreferences("myDetails",MODE_PRIVATE); // SharedPreferences creates a files of name mydetails is a XML file

        // these lines are supposed to be written after onStop() method
        // the "Name" is the tag associated with name in onStop() hence it has to eb written here to store name
        n.setText(sp.getString("Name",""));
        p.setText(sp.getLong("Phone",0)+"");

    }

    @Override
    protected void onStop() {
        super.onStop();
        SharedPreferences.Editor e= sp.edit();
        e.putString("Name",n.getText().toString());
        e.putLong("Phone",Integer.parseInt(p.getText().toString()));
        e.commit();

    }
}