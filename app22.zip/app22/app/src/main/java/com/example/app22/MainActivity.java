//Sending email to email app by implicit intent
package com.example.app22;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText s,t,e;
    Button b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        s=findViewById(R.id.sub);
        t=findViewById(R.id.content);
        e=findViewById(R.id.email);
        b=findViewById(R.id.button);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(Intent.ACTION_SEND);
                i.putExtra(Intent.EXTRA_EMAIL,new String[]{e.getText().toString()}); // takes string array because it can have multiple email addresses
                // e will take string and we need to put to a string array while using the above statement , can be done using
                i.putExtra(Intent.EXTRA_TEXT,t.getText().toString()); // takes string
                i.putExtra(Intent.EXTRA_SUBJECT,s.getText().toString()); // takes string
                //i.putExtra(Intent.EXTRA_BCC,); // takes string array because it can have multiple email addresses
                //i.putExtra(Intent.EXTRA_CC,); // takes string array because it can have multiple email addresses

                // we've to distinguish between messaging apps and email apps hence setType is used
                i.setType("message/rfc822");
                startActivity(i);

            }
        });
    }
}