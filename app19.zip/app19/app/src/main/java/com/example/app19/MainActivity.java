//Implicit intent
       // 1. To call and redirection
       // 2. Give text url and redirect to browser
       // 3. Maps
       // 4. Navigation

package com.example.app19;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button b;
    EditText n;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b=findViewById(R.id.button);
        n=findViewById(R.id.num);
        b.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {

 /*
            //1. To call and redirection to phone apps
            //DIAL is not directly able to place a call. It redirects to phone app on realme

                Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+n.getText().toString()));
                startActivity(Intent.createChooser(i,"Choose application"));

                //Intent i1 = new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+n.getText().toString()));

            //here we will get an error because a call is not placed. now we've to give explicit permissions. start activity is causing the error
            //scheme associated with telephone number is tel

            // this below part of code is written to ask for permissions to allow or deny
                if(checkSelfPermission(Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED)
                {
                    //check manifest file for a uses-permission line
                    //here we are requesting for permissions
                    requestPermissions(new String[]{Manifest.permission.CALL_PHONE},1);
                }
                else
                    startActivity(i);

*/

            /*
            2. Give text url and redirect to browser
            // for this just change input type to text in xml file
            // this will redirect to browser
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://"+n.getText().toString()));
                startActivity(i);

            */
            /*
            3. To redirect to maps
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?"));
                startActivity(i);
            */


            //4. To redirect to NMAMIT i.e to search for place
              //  Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=NMAMIT,Nitte" )); // q is the query
                //startActivity(i);

                //To use google.navigation
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=PVS, Mangalore" ));
                startActivity(i);

            }
        });

    }
}