package com.example.app4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button s,c;
    RadioGroup rg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        s=findViewById(R.id.submit);
        c=findViewById(R.id.clear);
        rg=findViewById(R.id.ele);
        s.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = rg.getCheckedRadioButtonId();// id extracted from radiogroup is integer to checl which radio button is extracted
                if(id==-1)
                    Toast.makeText(MainActivity.this,"No item selected",Toast.LENGTH_SHORT).show();
                else {
                    RadioButton r1 = findViewById(id);
                    Toast.makeText(MainActivity.this, r1.getText().toString(), Toast.LENGTH_SHORT).show();
                }
            }
        });
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rg.clearCheck();
            }
        });
    }
}