package com.example.app38;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;

public class MyService extends Service {

    MediaPlayer mp;
    public MyService() {
    }

    @Override
    public void onCreate() {
        super.onCreate();
        // this is initialisation
        mp=MediaPlayer.create(getApplicationContext(),R.raw.office_theme);
        // here we can't use Mainactivity.this instead use getApplicationContext()
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        mp.start();
        NotificationManager m= (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification not;
        if(Build.VERSION.SDK_INT>=26)
        {
            NotificationChannel nc= new NotificationChannel("ch1","channel1",NotificationManager.IMPORTANCE_HIGH);
            m.createNotificationChannel(nc);
            Notification.Builder nb= new Notification.Builder(getApplicationContext(),"ch1");
            not= nb.build();
        }
        else
        {
            Notification.Builder nb= new Notification.Builder(getApplicationContext());
            not= nb.build();
        }
        startForeground(startId,not);
        // not is created outside so that it can be passed in the above method
        //startId is obtained from onStartCommand
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mp.stop();
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}