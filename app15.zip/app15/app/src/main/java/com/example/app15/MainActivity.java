package com.example.app15;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView l;
    ArrayAdapter<String> adp;
    EditText e;
    Button b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        l=findViewById(R.id.ld);
        e=findViewById(R.id.txt);
        b=findViewById(R.id.button);
        //String[] arr= {"Norway","Sweden","Albania","USA"};
        ArrayList arr=new ArrayList();
        arr.add("Norway");
        arr.add("India");
        // contents of array should be populated with listview that is they should be linked
        // array adapter takes contents of arr and puts it into the listview
        adp= new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1,arr);
        // we use android.R.layout to access from Layout view which isn't in Res layout folder
        l.setAdapter(adp); // static listview

        // for highlighting entire row give match parent in layout width in activity.xml
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // add item to listview which is in edit text
                String s= e.getText().toString();
                if(s.equals(""))
                    Toast.makeText(MainActivity.this, "Enter the item name", Toast.LENGTH_SHORT).show();
                else
                /*{
                    // add an element to the array
                    //String array doesn't allow to change the original contents i.e no dynamic array
                    arr.add(s); // here we're only adding to the array
                    // now we need to update the listview through Adapter object
                    adp.notifyDataSetChanged(); // data set associated with adp is arr. We're saying that arr has changed
                }
                */
                {
                    if(arr.contains(s))
                    {
                        Toast.makeText(MainActivity.this, "Item already present", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        arr.add(s);
                        adp.notifyDataSetChanged();
                    }

                }
            }
        });
        l.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String st= arr.get(i).toString();
                Toast.makeText(MainActivity.this,st+" Selected", Toast.LENGTH_SHORT).show();

            }
        });

        l.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                AlertDialog.Builder alert=new AlertDialog.Builder(MainActivity.this);
                // this object is used to ask yes or no before deleting
                alert.setMessage("Delete?");
                alert.setTitle("ALERT");
                alert.setCancelable(false);  // alert box won't disappear on clocking somewhere outside it
                alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i1) {
                        arr.remove(i); //int i here is the index of the item to  be removed pointing to line 73
                        adp.notifyDataSetChanged();
                    }
                });
                alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel(); // cancelling wrt to object of class
                    }
                });
                AlertDialog a =alert.create(); // building an interface of alert dialog
                a.show();

                return true;

            }
        });

    }

}